# ptokens-utils

This module allows to have access to some usefull utility used by other packages.

&nbsp;

***

&nbsp;

### Installation:

```
npm install ptokens-utils
```

&nbsp;

***

&nbsp;

### Usage

```js
import * as utils from 'ptokens-utils'

{ eth:
   [Object: null prototype] {
     addHexPrefix: [Function: addHexPrefix],
     removeHexPrefix: [Function: removeHexPrefix],
     ....
```
